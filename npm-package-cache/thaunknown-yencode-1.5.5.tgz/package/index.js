import y from './y.cjs';
const RE_YPROP = /([a-z_][a-z_0-9]*)=/;
const RE_BADCHAR = /\r\n\0/g;
const nl = Buffer.from([13, 10]);
export const decode = y.decode ?? function (data, stripDots) {
    const buffer = Buffer.allocUnsafe(data.length);
    const length = y.decodeTo(data, buffer, stripDots);
    return buffer.subarray(0, length);
};
const decoderParseLines = function (lines, ydata) {
    for (let i = 0; i < lines.length; i++) {
        const yprops = {};
        let line = lines[i].substring(2); // cut off '=y'
        // parse tag
        let p = line.indexOf(' ');
        const tag = (p < 0 ? line : line.substring(0, p));
        line = line.substring(tag.length + 1).trim();
        // parse props
        let m = line.match(RE_YPROP);
        while (m) {
            const prop = m[1];
            let val;
            const valPos = (m.index ?? 0) + m[0].length;
            if (tag === 'begin' && prop === 'name') {
                // special treatment of filename - the value is the rest of the line (can include spaces)
                val = line.substring(valPos);
                line = '';
            }
            else {
                p = line.indexOf(' ', valPos);
                val = (p < 0 ? line.substring(valPos) : line.substring(valPos, p));
                line = line.substring(valPos + val.length + 1);
            }
            yprops[prop] = val;
            m = line.match(RE_YPROP);
        }
        // @ts-expect-error idfk
        ydata[tag] = yprops;
    }
};
export function fromPost(data, props = true) {
    if (!Buffer.isBuffer(data))
        throw new TypeError('Expected string or Buffer');
    const ret = {};
    // find '=ybegin' to know where the yEnc data starts
    let yencStart;
    if (data.subarray(0, 8).toString('hex') === '3d79626567696e20' /* =ybegin */) {
        // common case: starts right at the beginning
        yencStart = 0;
    }
    else {
        // otherwise, we have to search for the beginning marker
        yencStart = data.indexOf('\r\n=ybegin ');
        if (yencStart < 0)
            throw new Error('yEnc start marker not found');
        yencStart += 2;
    }
    ret.yencStart = yencStart;
    // find all start lines
    const lines = [];
    let sp = yencStart;
    let p = data.indexOf('\r\n', yencStart + 8);
    while (p > 0) {
        const line = data.subarray(sp, p).toString('utf8').trim();
        lines.push(line);
        sp = p + 2;
        if (line.substring(0, 6) === '=yend ') { // no data in post
            ret.yencEnd = sp;
            break;
        }
        if (data[sp] !== 0x3d /* = */ || data[sp + 1] !== 0x79 /* y */) {
            ret.dataStart = sp;
            break;
        }
        p = data.indexOf('\r\n', sp);
    }
    // reached end of data but '=yend' not found
    if (!ret.dataStart && !ret.yencEnd)
        throw new Error('yEnd end marker not found');
    const ydata = {};
    if (props)
        decoderParseLines(lines, ydata);
    if (!ret.yencEnd) {
        let yencEnd = data.subarray(ret.dataStart).lastIndexOf('\r\n=yend ', -1);
        if (yencEnd < 0)
            throw new Error('yEnd end marker not found');
        yencEnd += ret.dataStart;
        ret.dataEnd = yencEnd;
        p = data.indexOf('\r\n', yencEnd + 8);
        if (p < 0) {
            p = data.length;
            ret.yencEnd = p;
        }
        else {
            ret.yencEnd = p + 2;
        }
        if (props) {
            const endLine = data.subarray(yencEnd + 2, p).toString('utf8').trim();
            decoderParseLines([endLine], ydata);
        }
    }
    if (props) {
        ret.props = ydata;
        // check properties
        // required properties, according to yEnc 1.2 spec
        if (!ydata.begin.line || !ydata.begin.size || !('name' in ydata.begin))
            throw new Error('Could not find line/size/name properties on ybegin line');
        if (!ydata.end.size)
            throw new Error('Could not find size properties on yend line');
    }
    if (ret.dataStart) {
        ret.data = decode(data.subarray(ret.dataStart, ret.dataEnd), false);
    }
    return ret;
}
export const minSize = function (length, lineSize) {
    if (!length)
        return 0;
    return length + // no characters escaped
        2 * Math.floor(length / (lineSize || 128)); // newlines
};
export const maxSize = function (length, lineSize, escRatio = 2) {
    if (!length)
        return 0;
    if (escRatio !== 2)
        escRatio++;
    if (escRatio < 1 || escRatio > 2) {
        throw new Error('yEnc escape ratio must be between 0 and 1');
    }
    return Math.ceil(length * escRatio) + // all characters escaped
        2 * Math.floor((length * escRatio) / (lineSize || 128)) + // newlines, considering the possibility of all chars escaped
        2 + // allocation for offset and that a newline may occur early
        64; // extra space just in case things go awry... just kidding, it's just extra padding to make SIMD logic easier
};
export const encode = y.encode ?? function (data, lineSize, columnOffset) {
    const buffer = Buffer.allocUnsafe(maxSize(data.length, lineSize));
    return buffer.subarray(0, y.encodeTo(data, buffer, lineSize, columnOffset));
};
export const encodeTo = y.encodeTo;
export const decodeTo = y.decodeTo;
export const crc32 = y.crc32;
export const crc32Combine = y.crc32_combine;
export const crc32Zeroes = y.crc32_zeroes;
export const crc32Multiply = y.crc32_multiply;
export const crc32Shift = y.crc32_shift;
export const post = function (filename, data, lineSize = 128) {
    const filenameBuffer = Buffer.from(filename.replace(RE_BADCHAR, '').substring(0, 256), exports.encoding);
    const yBegin = '=ybegin line=' + lineSize + ' size=' + data.length + ' name=';
    const yEnd = '\r\n=yend size=' + data.length + ' crc32=';
    const ret = Buffer.allocUnsafe(yBegin.length + filenameBuffer.length + 2 + module.exports.maxSize(data.length, lineSize) + yEnd.length + 8);
    let writePos = ret.write(yBegin);
    writePos += filenameBuffer.copy(ret, writePos);
    writePos += nl.copy(ret, writePos);
    writePos += y.encodeTo(data, ret.subarray(writePos), lineSize);
    writePos += ret.write(yEnd + y.crc32(data).toString('hex'), writePos);
    return ret.subarray(0, writePos);
};
//# sourceMappingURL=index.js.map