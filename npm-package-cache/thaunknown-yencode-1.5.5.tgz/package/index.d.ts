interface YencData {
    yencStart: number;
    dataStart: number;
    dataEnd: number;
    yencEnd: number;
    props: {
        begin: {
            part: string;
            total: string;
            line: string;
            size: string;
            name: string;
        };
        part: {
            begin: string;
            end: string;
        };
        end: {
            size: string;
            part: string;
            pcrc32: string;
        };
    } | null;
    data: Buffer;
    crc32: Buffer;
    warnings: Array<{
        code: string;
        message: string;
    }>;
}
export declare const decode: any;
export declare function fromPost(data: Buffer, props?: boolean): YencData;
export declare const minSize: (length: number, lineSize: number) => number;
export declare const maxSize: (length: number, lineSize: number, escRatio?: number) => number;
export declare const encode: any;
export declare const encodeTo: any;
export declare const decodeTo: any;
export declare const crc32: any;
export declare const crc32Combine: any;
export declare const crc32Zeroes: any;
export declare const crc32Multiply: any;
export declare const crc32Shift: any;
export declare const post: (filename: string, data: Buffer, lineSize?: number) => Buffer<ArrayBuffer>;
export {};
