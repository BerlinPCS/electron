declare const _default: {
  encode: (plain: string | Uint8Array) => Uint8Array;
  decode: (encoded: string | Uint8Array) => Uint8Array;
};
export default _default;
